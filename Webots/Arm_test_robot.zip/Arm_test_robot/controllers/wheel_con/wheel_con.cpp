#include <webots/Robot.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <webots/Camera.hpp>
#include <limits>
#include <subtask.cpp>
#include <Wheels.cpp>
#include <map>
#include <cmath>

 
void printFactors(int n){
    std::cout<<"Factors: "<<" ";
    for(int i=1; i<n/2+1; i++){
        if(n%i==0){
            std::cout<<i<<", ";
        }
    }
    std::cout<<n<<std::endl;
}

double getTurnedAngle(Camera *camera){
	/* 90degree turns cannot be taken using only 2 IR sensors. 
	Robot stops turning small angle at the turn.
	At that point an image is captured and turned angle is calculated.
	It will be used to turn the robot to correct direction*/
	
  int cell[2];
  const unsigned char *image = camera->getImage();
  for (int y = 0; y < 64; y++){
    int r = camera->imageGetRed(image, 64, y, 0);
    
    if (r>=214){cell[0]=y; break;}
    else{cell[0]=0;}
  }
  for (int y = 0; y < 64; y++){
    int r = camera->imageGetRed(image, 64, y, 63);
    if (r>=214){cell[1]=y; break;}
    else{cell[1]=0;}
  }
  //std::cout<<cell[0]<<std::endl;
  //std::cout<<cell[1]<<std::endl;
  if (abs(cell[0]-cell[1])==0){return 90;}
  return atan(64/abs(cell[0]-cell[1]))*57.325;
}

int main(int argc, char **argv) {
  
  Robot *robot = new Robot();
  Wheels *wheels = new Wheels(robot);
  robot->step(500);
  
  
  int timeStep = (int)robot->getBasicTimeStep();
  DistanceSensor *ds_high = robot->getDistanceSensor("ds_high");
  ds_high->enable(8);
  DistanceSensor *ds_low = robot->getDistanceSensor("ds_low");
  ds_low->enable(8);
  Camera *camera = robot->getCamera("camera");
  camera->enable(16);
  
  wheels->goForward(0.08); //exit from the white cell
  std::string color = " ";
  while (robot->step(timeStep)!=-1){ //go until colored cell is found
    const unsigned char *image = camera->getImage();
    unsigned int red = camera->imageGetRed(image,64,32,32);
    unsigned int green = camera->imageGetGreen(image,64,32,32);
    unsigned int blue = camera->imageGetBlue(image,64,32,32);
    if (red>blue and red>green){
      color = "Red";
    } else if(blue>red and blue>green){
      color = "Blue";
    } else if(green>red and green>blue){
      color = "Green";
    } 
    
    if (color != " "){break;}
    wheels->setSpeed(6,6);
  }
  wheels->goForward(0.075);//go to center of the cell and print to console
  std::cout<<color<<std::endl;
  wheels->goForward(0.075);//exit cell
  
  int count = 0;
  int n = 0;
  
  while (robot->step(timeStep)!=-1){//line follow until next white cell
 
    if (!wheels->line_follow(false)){
      if (count==0){
        wheels->goForward(0.115);//move to center of the cell
        n = subtask(wheels,ds_high,ds_low); //perform subtask
        //std::cout<<n<<std::endl;
        wheels->goForward(0.045);//exit the cell
        count++;
      }else if (count==1){//line follow until junction
        wheels->goForward(0.04);
        break;
      }
    }
  }

  if (n!=0){wheels->turn(90);}//subtask done. turn left
  //wheels->goForward(0.45);
  //wheels->turn(270);
  while (robot->step(timeStep)!=-1){//line follow until next 90degree turn and turn right
    if(!wheels->line_follow(false)){
      double angle = getTurnedAngle(camera);
      //std::cout<<angle<<std::endl;
      wheels->turn(90-angle);
      wheels->goForward(0.04);
      wheels->turn(270);
      break;
    }
  }
  
  
  while (robot->step(timeStep)!=-1){//curved line follow
    if(!wheels->line_follow(true)){ // true parameter specified a curved line
      double angle = getTurnedAngle(camera);
      //std::cout<<angle<<std::endl;
      wheels->turn(90-angle);
      wheels->goForward(0.04);
      wheels->turn(270);
      break;
    }
  }
  
  while (robot->step(timeStep)!=-1){//until the next junction
    if(!wheels->line_follow(false)){
      double angle = getTurnedAngle(camera);
      //std::cout<<angle<<std::endl;
      wheels->turn(-90+angle);
      wheels->goForward(0.03); 
      wheels->turn(90);     
      break;
    }
  }
  //pre-define destinations using n value
  double left[4]   = {90,270,1,270};
  double mid[4] = {0,0,0,0};
  double right[4]  = {270,90,-1,90};
  std::map<int,double*> destination ;                                    
  destination[4] =  left;
  destination[8] = mid;
  destination[12] = right;
  
  int turn_count = 0;
  while (robot->step(timeStep)!=-1){
    if(!wheels->line_follow(false)){  
      if(turn_count==1){//for left and right only. line follow until last turn

        double angle = getTurnedAngle(camera);
        //std::cout<<angle<<std::endl;
        wheels->turn((90-angle)*destination[n][2]);
        wheels->goForward(0.04);
        break;
      }
      wheels->goForward(0.035);
      wheels->turn(destination[n][turn_count]); 
      turn_count++;
      if (n==8){break;}
    }
  }
  wheels->turn(destination[n][3]);//last turn
  //wheels->goForward(0.285);//to the center of cell
  
  while (robot->step(timeStep)!=-1){ //go until colored cell is found
    
    const unsigned char *image = camera->getImage();
    unsigned int red = camera->imageGetRed(image,64,0,0);
    unsigned int green = camera->imageGetGreen(image,64,0,0);
    unsigned int blue = camera->imageGetBlue(image,64,0,0);
    if (red!=blue or blue!=green or green!=red ){
      break;
    }
    if(!wheels->line_follow(false)){
      wheels->goForward(0.005);
      //break;
    };
  }
  wheels->goForward(0.09);
  printFactors(n);
  
  delete robot;
  return 0;
}
