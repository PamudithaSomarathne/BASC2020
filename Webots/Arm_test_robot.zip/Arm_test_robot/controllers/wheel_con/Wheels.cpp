#pragma once
#include <webots/Robot.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <limits>

using namespace webots;

class Wheels{
  private:
    Robot *robot; 
    Motor *left_motor;Motor *right_motor;
    PositionSensor *left_encoder;PositionSensor *right_encoder;
    DistanceSensor *distance_sensor;
    bool first= true ;  
    double speed = 6;
    double tire = 0.025; //tire radius
  public:
    Wheels(Robot *r) { // Constructor with parameters
      this->robot = r;
      this->left_motor = this->robot->getMotor("left_motor");
      this->right_motor = this->robot->getMotor("right_motor");
      this->left_encoder = this->robot->getPositionSensor("left_encoder");
      this->right_encoder = this->robot->getPositionSensor("right_encoder");
      this->distance_sensor = this->robot->getDistanceSensor("ds_low");
	  
      this->left_motor->setPosition(std::numeric_limits<double>::infinity());
      this->right_motor->setPosition(std::numeric_limits<double>::infinity());
      this->left_motor->setVelocity(0.0);
      this->right_motor->setVelocity(0.0);
      this->left_encoder->enable(4);
      this->right_encoder->enable(4);
      this->distance_sensor->enable(8);  
      this->goForward(0);
    }
  public:
    void setSpeed(double l_speed,double r_speed){
      this->left_motor->setVelocity(l_speed);
      this->right_motor->setVelocity(r_speed);
    }
  public:
    bool goForward(double dis){//go forward a given distance
      double prev_left = this->left_encoder->getValue();
      double prev_right = this->right_encoder->getValue();
      if (this->first){
        prev_left=0;prev_right = 0;
        this->first = false;
      } 
            
      double left_limit = prev_left + (dis/this->tire);
      double right_limit = prev_right + (dis/this->tire);
      this->setSpeed(speed,speed);
      while (this->robot->step(10)!=-1){
        if (this->left_encoder->getValue()>=left_limit){
          this->left_motor->setVelocity(0.0);
        }
        if (this->right_encoder->getValue()>=right_limit){
          this->right_motor->setVelocity(0.0);
        }
        if ((this->left_encoder->getValue() >= left_limit) && (this->right_encoder->getValue() >= right_limit)){
          break;
        } 
      }
      this->setSpeed(0.0,0.0);
      return true;
    }
  public:
    double forward(){//go forward upto a wall.
      double prev_left = this->left_encoder->getValue();
			
      this->setSpeed(speed,speed);
      while (this->robot->step(4)!=-1){
        if (this->distance_sensor->getValue() < 0.1){
          this->setSpeed(0.0,0.0);
          break;
          	
        }
      }
			
      double dis =  (this->left_encoder->getValue() - prev_left)*this->tire;
      return dis;
    }
  private:
    bool turning(double left,double right){//turn a specified angle
      double prev_left = this->left_encoder->getValue();
      double prev_right = this->right_encoder->getValue();
	 
      double left_limit = prev_left + (left/this->tire);
      double right_limit = prev_right + (right/this->tire);
      if (left<right){
        //left_limit += 0.0175; // -1 degree
				//right_limit -= 0.0175;
				
				
				this->setSpeed(-this->speed * 0.25,this->speed *0.25);
				while (this->robot->step(4)!=-1){
				
          if ((this->left_encoder->getValue() <= left_limit) && (this->right_encoder->getValue() >= right_limit)){
						break;
          } 
        }
      }else{
				//left_limit -= 0.0175; // -1 degree
				//right_limit += 0.0175;
				this->setSpeed(this->speed * 0.25,-this->speed *0.25);
        while (this->robot->step(4)!=-1){
					
					if ((this->left_encoder->getValue() >= left_limit) && (this->right_encoder->getValue() <= right_limit)){
						break;
					} 
        }
      }
      this->setSpeed(0.0,0.0);
      return true;
    }
  
  public :
    int turn(double angle){//convert angle to radians and pass to private method
			if (angle>180){angle = (360-angle)*-1;}
			if (angle==180){angle = -180;}
			//angle -=1; 
			this->turning(-0.06*(angle/180)*3.14,0.06*(angle/180)*3.14);
			return 1;
      
    }
	
		bool line_follow(bool curved){
			
			DistanceSensor *left = this->robot->getDistanceSensor("ds_down_left");
			DistanceSensor *right = this->robot->getDistanceSensor("ds_down_right"); 
			left->enable(8);
			right->enable(8);
			double lspeed,rspeed;
			if (curved){//for curved line speed is lowered
				lspeed = this->speed*0.5;
				rspeed = this->speed*0.5;
			}else{
				lspeed = this->speed*0.75;
				rspeed = this->speed*0.75;
			}
			double lval = left->getValue();
			double rval = right->getValue();
			/*std::cout<<"left: "<<std::flush;
			std::cout<<lval<<std::flush;
			std::cout<<"  right: "<<std::flush;
			std::cout<<rval<<std::endl;*/
			
			//ir range set to 5cm. if black it is 0.05 and if white <0.05
			if (lval<0.05 && rval<0.05){
				this->left_motor->setVelocity(0.0);
				this->right_motor->setVelocity(0.0);
				return false;
			}
			if (lval<rval && lval<0.05){
			 lspeed = -lspeed;
			 //std::cout<<"left"<<std::endl;
		 }
		 else if (rval<lval && rval<0.05){
			 rspeed = -rspeed;
			 //std::cout<<"right"<<std::endl;
		 }
		 
		 this->left_motor->setVelocity(lspeed);
		 this->right_motor->setVelocity(rspeed);
	
		 return true;
		}
		void wall_follow(){
			while (this->robot->step(16)){
				this->forward();
				this->turn(90);
				if (this->distance_sensor->getValue()<0.1){
					this->turn(180);
				}
			}
		}
};