#pragma once
#include "Wheels.cpp"
#include <webots/DistanceSensor.hpp>
#include <webots/PositionSensor.hpp>
using namespace webots;

int subtask(Wheels *wheels,DistanceSensor *ds_high,DistanceSensor *ds_low){
	//two ir sensors are mounted at front of the robot. 
	//robot turns and take readings and calculate n.
	int distance[2] = {0,0};
	int height[2];//1 if 4cm,2 if 8cm
	int right_value ;int left_value;
	double calibrated[3] = {0.12,0.19,0.25};
	int walls[3] = {4,8,12};
	
	wheels->turn(90);
	
	double temp = ds_low->getValue();
	//std::cout<<temp<<std::endl;
	for (int i=0;i<3;i++){
		if (temp<calibrated[i]){
			distance[0] = walls[i];
			break;
		}
	}
	if (ds_high->getValue()<0.5){
		height[0] = 2;
	}else{
		height[0] = 1;
	}
	wheels->turn(180);
	
	temp = ds_low->getValue();
	//std::cout<<temp<<std::endl;
	for (int i=0;i<3;i++){
		if (temp<calibrated[i]){
			distance[1] = walls[i];
			break;
		}
	}
	if (ds_high->getValue()<0.5){
		height[1] = 2;
	}else{
		height[1] = 1;
	}
	
	wheels->turn(90);
	
	left_value = distance[0]*height[0];
	right_value = distance[1]*height[1];
	
	std::cout<<"Right value: "<<std::flush;
	std::cout<<right_value<<std::endl;
	std::cout<<"Left value: "<<std::flush;
  std::cout<<left_value<<std::endl;
	
	int n = abs(right_value - left_value);
	
	return n;
}
/* //implementation for ir range=5cm as given at the start.
int subtask(Wheels *wheels,DistanceSensor *ds){
	//ir range = 0.05 cm
	double distance[2];
	int height[2];//1 if 4cm,2 if 8cm
	int right_value;int left_value;
	double arr[3] = {0.04,0.08,0.12};
	wheels->turn(90);
	
	for (int j=0;j<2;j++){
		
		double temp = wheels->forward();
		for (int i=0;i<3;i++){
			if (temp<arr[i]){
				distance[j] = arr[i];
				break;
			}
			
		}
		//std::cout<<j<<std::endl;
		if ( ds->getValue() < 0.05){
			height[j] = 2;
		}else{
			height[j] = 1;
		}
		
		wheels->turn(180);
		wheels->goForward(temp);
	}
	wheels->turn(270);
	left_value = (int)(distance[0]*100*height[0]);
	right_value = (int) (distance[1]*100*height[1]);
	std::cout<<"Right value: "<<std::flush;
	std::cout<<right_value<<std::endl;
	std::cout<<"Left value: "<<std::flush;
  std::cout<<left_value<<std::endl;
	int n = abs(right_value - left_value);
	
	return n;
	
}*/