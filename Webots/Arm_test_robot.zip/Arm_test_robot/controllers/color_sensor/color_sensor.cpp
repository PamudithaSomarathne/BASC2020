// File:          color_sensor.cpp
// Date:
// Description:
// Author:
// Modifications:

// You may need to add webots include files such as
// <webots/DistanceSensor.hpp>, <webots/Motor.hpp>, etc.
// and/or to add some other includes
#include <webots/Robot.hpp>
#include <webots/LightSensor.hpp>
// All the webots classes are defined in the "webots" namespace
using namespace webots;
using namespace std;
// This is the main program of your controller.
// It creates an instance of your Robot instance, launches its
// function(s) and destroys it at the end of the execution.
// Note that only one instance of Robot should be created in
// a controller program.
// The arguments of the main function can be specified by the
// "controllerArgs" field of the Robot node
int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  LightSensor *light_sensor[3];
  light_sensor[0]=robot->getLightSensor("LS_red");
  light_sensor[1]=robot->getLightSensor("LS_green");
  light_sensor[2]=robot->getLightSensor("LS_blue");
  light_sensor[0]->enable(10);
  light_sensor[1]->enable(10);
  light_sensor[2]->enable(10);
  // get the time step of the current world.
  int timeStep = (int)robot->getBasicTimeStep();
  double value_r;
  double value_g;
  double value_b;

  // Main loop:
  // - perform simulation steps until Webots is stopping the controller
  while (robot->step(timeStep) != -1) {
  
    value_r=light_sensor[0]->getValue();
    cout<<value_r<<" ";
    value_g=light_sensor[1]->getValue();
    cout<<value_g<<" ";
    value_b=light_sensor[2]->getValue();
    cout<<value_b<<endl;
    
    if (value_r>value_g && value_r>value_b)
      cout<<"Color: Red"<<endl;
    else if (value_g>value_r && value_g>value_b)
      cout<<"Color: green"<<endl;
    else
      cout<<"Color: Blue"<<endl;
    // Read the sensors:
    // Enter here functions to read sensor data, like:
    //  double val = ds->getValue();

    // Process sensor data here.

    // Enter here functions to send actuator commands, like:
    //  motor->setPosition(10.0);
  };

  // Enter here exit cleanup code.

  delete robot;
  return 0;
}
