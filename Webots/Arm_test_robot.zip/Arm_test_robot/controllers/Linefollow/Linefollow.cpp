#include <webots/Motor.hpp>
#include <webots/Robot.hpp>
//#include <webots/LED.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Camera.hpp>
#define TIME_STEP 64
using namespace webots;
using namespace std;



int main(int argc, char **argv) {
 
  Robot *robot = new Robot();
  //LED *LED_show[7];
  Motor *wheels[4];
  Camera *camera[1];
  DistanceSensor *S[5];
  int TH = 500;
 // int count = 0;
  float I=0;
 // bool start = true;
  char wheels_names[4][4] = {"LF", "LB", "RF", "RB"};
  char dsNames[6][3] = {"S1", "S2", "S3", "S4", "S5","S6"};
  char cameraNames[1][10]={"camera"};
  camera[0]=robot->getCamera(cameraNames[0]);
  camera[0]->enable(10);
  int pre_error=0;
  for (int i = 0; i < 4; i++) {
    wheels[i] = robot->getMotor(wheels_names[i]);
    wheels[i]->setPosition(INFINITY);
    wheels[i]->setVelocity(1);
  }
 // char LED_names[7][10] = {"led1", "led2", "led3", "led4", "led5", "Start_LED", "End_LED"};
  /*for (int i = 0; i < 7; i++) {
    LED_show[i] = robot->getLED(LED_names[i]);
  }*/
  for (int i = 0; i < 5; i++) {
    S[i] = robot->getDistanceSensor(dsNames[i]);
    S[i]->enable(TIME_STEP);
  }
 for (int i = 0; i < 4; i++) {
       // wheels[i]->setPosition(INFINITY);
  
      }
  /////////simulation starts///////
  while (robot->step(TIME_STEP) != -1) {
  
  ///////////start
    bool Ir1 = (S[0]->getValue()) < TH;
    bool Ir2 = (S[1]->getValue()) < TH;
    bool Ir3 = (S[2]->getValue()) < TH;
    bool Ir4 = (S[3]->getValue()) < TH;
    bool Ir5 = (S[4]->getValue()) < TH;
    bool Ir6 = (S[5]->getValue()) < TH;
  // std::cout<<Ir1<<Ir2<<Ir3<<Ir4<<Ir5<<Ir6<<std::endl;
    int error=-2*Ir2+-1*Ir3+Ir4+2*Ir5;
    cout<<Ir1<<" "<<Ir2<<" "<<Ir3<<" "<<Ir4<<" "<<Ir5<<" "<<Ir6<<endl;
  //  std::cout<<error<<std::endl;
    float Kp=1;
    float Kd=1;
    float Ki=0.001;
    
    float P= error*Kp;
    I=(I+error)*Ki;
    float D= (error-pre_error)*Kd;
    pre_error=error;
    
    float PID=P+I+D;
    
    int mid_speed=4;
    
    int left_speed=mid_speed-PID;
    int right_speed=mid_speed+PID;
    
    if(left_speed>6.28)
      left_speed=6.28;
    
    else if(left_speed<0)
      left_speed=0;
    
    if(right_speed>6.28)
      right_speed=6.28;
    
    else if(right_speed<0)
      right_speed=0;    
      
    
  //  std::cout<<"L:"<<left_speed<<std::endl;
  //  std::cout<<"R:"<<right_speed<<std::endl;
 //  std::cout<<"M:"<<mid_speed<<std::endl;
 //   std::cout<<"PID:"<<PID<<std::endl;
    wheels[0]->setVelocity(left_speed);
    wheels[1]->setVelocity(left_speed);
    wheels[2]->setVelocity(right_speed);
    wheels[3]->setVelocity(right_speed);
    /*LED_show[0]->set(255 * Ir1);
    LED_show[1]->set(255 * Ir2);
    LED_show[2]->set(255 * Ir3);
    LED_show[3]->set(255 * Ir4);
    LED_show[4]->set(255 * Ir5);*/
    
    
    
        //printf("red=%d, green=%d, blue=%d", r, g, b);
     // }
      
    
   if(Ir2==1 && Ir3==1 && Ir5==1 && Ir4==1){
     for (int y=0;y<1000;y++)
       continue;
       
     wheels[0]->setVelocity(0);
     wheels[1]->setVelocity(0);
     wheels[2]->setVelocity(0);
     wheels[3]->setVelocity(0);
     
     int image_width=camera[0]->getWidth();
  //  int image_height=camera[0]->getHeight();
    const unsigned char *image =camera[0]->getImage();
  //  for (int x = 0; x < image_width; x++)
  //    for (int y = 0; y < image_height; y++) {
        int r = camera[0]->imageGetRed(image, image_width, 32, 32);
        int g = camera[0]->imageGetGreen(image, image_width, 32, 32);
        int b = camera[0]->imageGetBlue(image, image_width, 32, 32);
        cout<<r<<"   "<<"   "<<g<<"   "<<b<<endl;
     
     if (r>g && r>b)
       const char Col="Red";
     else if (g>r && g>b)
       const char Col="Green";
     else
       const char Col="Blue";
       
     cout<<Col<<endl;
   


  }
}
