// File:          Arm_controller.cpp
// Date:
// Description:
// Author:
// Modifications:

// You may need to add webots include files such as
// <webots/DistanceSensor.hpp>, <webots/Motor.hpp>, etc.
// and/or to add some other includes
#include <webots/Motor.hpp>
#include <webots/Robot.hpp>
#include <webots/PositionSensor.hpp>
#define TIME_STEP 32
// All the webots classes are defined in the "webots" namespace
using namespace webots;
using namespace std;
// This is the main program of your controller.
// It creates an instance of your Robot instance, launches its
// function(s) and destroys it at the end of the execution.
// Note that only one instance of Robot should be created in
// a controller program.
// The arguments of the main function can be specified by the
// "controllerArgs" field of the Robot node
int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  Motor *lr_M;
  lr_M=robot->getMotor("arm_verticle");
  
  Motor *lr_S;
  lr_S=robot->getMotor("Slider");
  
  
  
  
  /*PositionSensor *PS;
  PS=robot->getPositionSensor("PS_1");
  PS->enable(TIME_STEP);
  */
  //double position = 0.0;
  // get the time step of the current world.
  //int timeStep = (int)robot->getBasicTimeStep();

  // You should insert a getDevice-like function in order to get the
  // instance of a device of the robot. Something like:
  //  Motor *motor = robot->getMotor("motorname");
  //  DistanceSensor *ds = robot->getDistanceSensor("dsname");
  //  ds->enable(timeStep);

  
  
  while (robot->step(TIME_STEP) != -1) {
      lr_S->setPosition(-0.01);
      
      
  }
  
  return 0;
}
