// File:          Wall_follow.cpp
// Date:
// Description:
// Author:
// Modifications:

// You may need to add webots include files such as
// <webots/DistanceSensor.hpp>, <webots/Motor.hpp>, etc.
// and/or to add some other includes
#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
#include <math.h>
// All the webots classes are defined in the "webots" namespace

#define TIME_STEP 32
using namespace webots;
using namespace std;


int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  Motor *wheels[2];
  DistanceSensor *S[4];
  char wheels_names[2][8] = {"L_wheel", "R_wheel"};
  char dsNames[4][6] = {"DS_lf", "DS_lr", "DS_rr", "DS_rf"};
  // get the time step of the current world.
  int timeStep = (int)robot->getBasicTimeStep();
  int TH=500;
  float Error;
  int k=100;
  int Mid_speed=2;
  float left_speed;
  float right_speed;
  
  
  
  for (int i = 0; i < 4; i++) {
    S[i] = robot->getDistanceSensor(dsNames[i]);
    S[i]->enable(TIME_STEP);
  }
  
  for (int i = 0; i < 2; i++) {
    wheels[i] = robot->getMotor(wheels_names[i]);
    wheels[i]->setPosition(INFINITY);
    wheels[i]->setVelocity(1);
    
  }
  
  

  // You should insert a getDevice-like function in order to get the
  // instance of a device of the robot. Something like:
  //  Motor *motor = robot->getMotor("motorname");
  //  DistanceSensor *ds = robot->getDistanceSensor("dsname");
  //  ds->enable(timeStep);

  // Main loop:
  // - perform simulation steps until Webots is stopping the controller
  while (robot->step(timeStep) != -1) {
    float Ir_lf = S[0]->getValue() ;
    float Ir_lr = S[1]->getValue() ;
    float Ir_rr = S[2]->getValue() ;
    float Ir_rf = S[3]->getValue() ;
    cout<<Ir_lf<<" "<<Ir_lr<<" "<<Ir_rr<<" "<<Ir_rf<<endl;
    
    if (Ir_lf>TH && Ir_lr>TH){
      Error= (Ir_rf-Ir_rr)/k;
      left_speed=Mid_speed+Error;
      right_speed=Mid_speed-Error;
    }
    
    else if (Ir_rf<TH && Ir_rr<TH && Ir_lr>TH ){
      Error= (Ir_rf-Ir_rr)/k;
      left_speed=Mid_speed+Error;
      right_speed=Mid_speed-Error;
    }
    else if (Ir_rf>TH && Ir_rr<TH && Ir_lr>TH ){
      
      left_speed=Mid_speed;
      right_speed=Mid_speed;
    }
    
    else if (Ir_lr>TH && Ir_rr>TH ){
      
      left_speed=Mid_speed;
      right_speed=Mid_speed;
    }
    else{
      Error= (Ir_lf-Ir_lr)/k;
      left_speed=Mid_speed-Error;
      right_speed=Mid_speed+Error;
    }
    
    cout<<Error<<endl;
    
    if(left_speed>6.28)
      left_speed=6.28;
    
    else if(left_speed<0)
      left_speed=0;
    
    if(right_speed>6.28)
      right_speed=6.28;
    
    else if(right_speed<0)
      right_speed=0;    
      
    
    wheels[0]->setVelocity(left_speed);
    wheels[1]->setVelocity(right_speed);
    cout<<left_speed<<" "<<right_speed<<endl;
    // Read the sensors:
    // Enter here functions to read sensor data, like:
    //  double val = ds->getValue();

    // Process sensor data here.

    // Enter here functions to send actuator commands, like:
    //  motor->setPosition(10.0);
  };

  // Enter here exit cleanup code.

  
  return 0;
}
