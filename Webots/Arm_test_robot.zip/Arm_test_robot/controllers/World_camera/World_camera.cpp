#include <webots/Robot.hpp>
#include <webots/Camera.hpp>
#define TIME_STEP 64
using namespace webots;
using namespace std;

int main(int argc, char **argv) {
  Robot *robot = new Robot();
  
  Camera *camera[1];
  
  char cameraNames[1][10]={"camera"};
  camera[0]=robot->getCamera(cameraNames[0]);
  camera[0]->enable(10);
  
  while (robot->step(TIME_STEP) != -1) {
    //int  image_hight=512; 
    //int  image_width=512;
    int image_width=camera[0]->getWidth();
  //  int image_height=camera[0]->getHeight();
    const unsigned char *image =camera[0]->getImage();
    
  }
}
